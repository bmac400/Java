The only dependecies are standard java util libraries.

The code is run through app.java however each of the different evaluator methods have a class for them. Run passing in a 2 maps and if applicable a k value.
