The only dependecy that is not native to java is the json-simple which is provided on the project page.
The code is run through the test class through the main function there. 